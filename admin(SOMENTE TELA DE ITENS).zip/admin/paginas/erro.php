<?php
    if(!isset($page)){
        exit;
    }
?>


<?php
    mensagemErro2("Sua pagina não foi localizada.")
?>

<!-- <div class="text-center">
    <img src="images/erro.png" alt="Pagina nao encontrada" class="w-100">
</div> -->